r"""2.2.0 köprüsü: "Yeni kurulum gerekli" penceresi (yalnız eski taşınabilir 2.1 programında çalışır).
Kurulum dosyasını GitHub Releases latest.json'dan (win-setup) indirir, SHA-256 ile doğrular, eski veri klasörünü
%APPDATA%\Organizer\eski-veri-konumu.txt'ye yazar (yeni program kayıtları oradan kopyalar; eski klasör silinmez),
programı kapatır ve kurulumu başlatır."""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel, QProgressBar, QPushButton, QVBoxLayout)

from . import i18n

YENI = "2.2.0"
LATEST = "https://github.com/departures-mil/organizer/releases/latest/download/latest.json"
SAYFA = "https://github.com/departures-mil/organizer/releases/latest"
M = {
    "tr": {"baslik": "Yeni kurulum gerekli",
           "p1": "Organizer {v} yeni bir kurulum programıyla gelir: yeni görünüm, tek tıkla güncelleme (yalnızca değişen kısımlar indirilir) ve daha güvenli eşitleme. Bir kez kurun; sonraki güncellemeler kendiliğinden gelir.",
           "p2": "Kayıtlarınız korunur: eşyalar, ustalar, fotoğraflar, ayarlar ve bulut bağlantısı yeni programa kopyalanır. Bu taşınabilir klasör silinmez.",
           "p3": "„İndir ve kur“ kurulum dosyasını indirir, bu programı kapatır ve kurulumu başlatır; birkaç saniye sonra yeni Organizer açılır. Masaüstüne yeni „Organizer“ kısayolu eklenir.",
           "kur": "İndir ve kur", "sayfa": "Sürümler sayfası", "sonra": "Daha sonra", "iniyor": "Kurulum dosyası indiriliyor",
           "hata": "Kurulum dosyası indirilemedi ({e}). Sürümler sayfasından indirebilirsiniz.", "kalan": "kalan", "dogrula": "Doğrulanıyor…"},
    "en": {"baslik": "New installer required",
           "p1": "Organizer {v} comes with a new installer: a new look, one-click updates (only the changed parts are downloaded) and safer sync. Install it once; later updates arrive automatically.",
           "p2": "Your records are kept: items, craftsmen, photos, settings and the cloud connection are copied to the new program. This portable folder is not deleted.",
           "p3": "\"Download and install\" downloads the installer, closes this program and starts the installation; the new Organizer opens a few seconds later. A new \"Organizer\" desktop shortcut is added.",
           "kur": "Download and install", "sayfa": "Releases page", "sonra": "Later", "iniyor": "Downloading the installer",
           "hata": "The installer could not be downloaded ({e}). You can download it from the releases page.", "kalan": "left", "dogrula": "Verifying…"},
    "ar": {"baslik": "يلزم مثبّت جديد",
           "p1": "يأتي Organizer {v} بمثبّت جديد: مظهر جديد، وتحديث بنقرة واحدة (تُنزَّل الأجزاء المتغيرة فقط)، ومزامنة أكثر أماناً. ثبّته مرة واحدة؛ وستصل التحديثات التالية تلقائياً.",
           "p2": "سجلاتك محفوظة: تُنسخ الأغراض والحرفيون والصور والإعدادات واتصال السحابة إلى البرنامج الجديد. لا يُحذف هذا المجلد المحمول.",
           "p3": "زر «تنزيل وتثبيت» ينزّل ملف التثبيت ويغلق هذا البرنامج ويبدأ التثبيت؛ ثم يُفتح Organizer الجديد بعد ثوانٍ. يُضاف اختصار جديد باسم «Organizer» على سطح المكتب.",
           "kur": "تنزيل وتثبيت", "sayfa": "صفحة الإصدارات", "sonra": "لاحقاً", "iniyor": "جارٍ تنزيل ملف التثبيت",
           "hata": "تعذّر تنزيل ملف التثبيت ({e}). يمكنك تنزيله من صفحة الإصدارات.", "kalan": "متبقٍ", "dogrula": "جارٍ التحقق…"},
}


def T(k, **kw):
    s = M.get(i18n.LANG, M["tr"]).get(k, M["tr"][k])
    return s.format(**kw) if kw else s


def _get(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "Organizer-kopru"})
    return urllib.request.urlopen(req, timeout=timeout)


def _mb(b):
    s = f"{b / 1048576:.1f}"
    return s.replace(".", ",") if i18n.LANG == "tr" else s


class _Is(QObject):
    ilerleme = Signal(str, int)
    bitti = Signal(str)
    hata = Signal(str)


def _isaret():
    """Kurulu sürüm kayıtları buradan kopyalasın: eski (taşınabilir) veri klasörü."""
    from .paths import data_dir
    eski = os.path.abspath(str(data_dir()))
    yeni = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Organizer")
    if os.path.normcase(eski) == os.path.normcase(os.path.abspath(yeni)):
        return
    os.makedirs(yeni, exist_ok=True)
    with open(os.path.join(yeni, "eski-veri-konumu.txt"), "w", encoding="utf-8") as f:
        f.write(eski)


def _indir(sinyal):
    try:
        with _get(LATEST) as r:
            man = json.loads(r.read().decode("utf-8"))
        a = (man.get("assets") or {}).get("win-setup") or {}
        if not a.get("file") or not a.get("sha256"):
            raise RuntimeError("win-setup")
        url = f"https://github.com/departures-mil/organizer/releases/download/v{man['version']}/{a['file']}"
        hedef = os.path.join(tempfile.gettempdir(), a["file"])
        top = int(a.get("size") or 0)
        h = hashlib.sha256()
        t0, n = time.monotonic(), 0
        with _get(url, timeout=60) as r, open(hedef + ".part", "wb") as f:
            while True:
                b = r.read(262144)
                if not b:
                    break
                f.write(b)
                h.update(b)
                n += len(b)
                hiz = n / max(0.001, time.monotonic() - t0)
                p = int(n * 100 / top) if top else 0
                sinyal.ilerleme.emit(f"%{p} · {_mb(n)} / {_mb(top)} MB · {T('kalan')} {_mb(max(top - n, 0))} MB · {_mb(hiz)} MB/s", p)
        sinyal.ilerleme.emit(T("dogrula"), 100)
        if h.hexdigest() != a["sha256"].lower():
            os.remove(hedef + ".part")
            raise RuntimeError("SHA-256")
        os.replace(hedef + ".part", hedef)
        sinyal.bitti.emit(hedef)
    except Exception as e:  # noqa: BLE001
        sinyal.hata.emit(str(e) or type(e).__name__)


class KopruPenceresi(QDialog):
    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.setWindowTitle(T("baslik"))
        self.setMinimumWidth(560)
        v = QVBoxLayout(self)
        v.setContentsMargins(24, 22, 24, 20)
        v.setSpacing(12)
        b = QLabel(T("baslik"))
        b.setObjectName("SectionTitle")
        v.addWidget(b)
        for k in ("p1", "p2", "p3"):
            l = QLabel(T(k, v=YENI))
            l.setWordWrap(True)
            v.addWidget(l)
        self.durum = QLabel("")
        self.durum.setWordWrap(True)
        self.cubuk = QProgressBar()
        self.cubuk.setRange(0, 100)
        self.cubuk.setTextVisible(False)
        self.cubuk.hide()
        v.addWidget(self.durum)
        v.addWidget(self.cubuk)
        r = QHBoxLayout()
        self.sayfa = QPushButton(T("sayfa"))
        self.sayfa.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(SAYFA)))
        self.sonra = QPushButton(T("sonra"))
        self.sonra.clicked.connect(self.reject)
        self.kur = QPushButton(T("kur"))
        self.kur.setObjectName("Primary")
        self.kur.clicked.connect(self._kur)
        r.addWidget(self.sayfa)
        r.addStretch(1)
        r.addWidget(self.sonra)
        r.addWidget(self.kur)
        v.addLayout(r)
        self.s = _Is()
        self.s.ilerleme.connect(self._ilerleme)
        self.s.bitti.connect(self._bitti)
        self.s.hata.connect(self._hata)

    def _kur(self):
        self.kur.setEnabled(False)
        self.sonra.setEnabled(False)
        self.cubuk.show()
        self.durum.setText(T("iniyor") + "…")
        threading.Thread(target=_indir, args=(self.s,), daemon=True).start()

    def _ilerleme(self, metin, p):
        self.durum.setText(T("iniyor") + "\n" + metin)
        self.cubuk.setValue(p)

    def _hata(self, e):
        self.durum.setText("⚠ " + T("hata", e=e))
        self.kur.setEnabled(True)
        self.sonra.setEnabled(True)

    def _bitti(self, yol):
        try:
            _isaret()
        except OSError:
            pass
        self.accept()
        try:
            self.win.close()          # son eşitleme (bulut) yapılır
        except Exception:
            pass
        flags = 0
        if sys.platform == "win32":
            flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        subprocess.Popen([yol], creationflags=flags, close_fds=True)
        QTimer.singleShot(400, QApplication.quit)


_acik = None


def goster(win):
    global _acik
    if _acik is not None and _acik.isVisible():
        _acik.raise_()
        return
    _acik = KopruPenceresi(win)
    _acik.show()
